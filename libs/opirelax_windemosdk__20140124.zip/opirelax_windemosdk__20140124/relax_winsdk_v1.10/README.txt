OP Innovations, Ltd.
Copyright 2014

Relax Software Development Kit (SDK) for Windows

Files included:
docs/OPIFileDefinition_v1.00_20130213.pdf
docs/OPILinkProtocol_v1.00_20120207.pdf
docs/OPIWiredFrameDefinition_v1.10_release_20131122.pdf
docs/Relax_winsdk_v1.10_20140124.pdf
opi_uce_win.h
opi_uce_win.cpp


We try to make our hardware platform as easy and open as possible, 
so we are providing a SDK for accessing our hardware. This is composed
of a .h file and .c file. Our hardware is accessed in windows 
through a virtual com port
that is created from the usb interface. The functions all access the com
port. In truth, you don't need to use our SDK since the protocol and
standards for 
communicating with the device (i.e. Unified Controller) and understanding
returned data is well-defined in related documents,
but our SDK is probably more convenient rather than writing everything 
from scratch.

This has been tested in Qt for Windows. We have written our demo 
applications in Qt and tested on Windows 7 and Windows XP. We tried to 
keep the SDK compatible with standard C. 

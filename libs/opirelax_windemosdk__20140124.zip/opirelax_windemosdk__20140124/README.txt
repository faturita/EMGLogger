This package for the OPI Relax Kit contains:
1) relax_winsrc_v1.01 - source code written using Qt libraries
for windows
2) relax_winsdk_v1.10 - documents and code relating to writing your 
own programs and accessing the OPI TrueSense Kit hardware in windows

Please see version file for more detailed information.

Disclaimer:
Despite the fact this software is intended to be useful, there is no 
warranty. Use this software at your own risk! This software may
NOT be used in safety-critical applications, such as life-support 
medical systems. The author is NOT responsible for any consequences. 
For research and educational purpose only.

